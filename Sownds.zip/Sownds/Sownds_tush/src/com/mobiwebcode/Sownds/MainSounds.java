package com.mobiwebcode.Sownds;

import java.util.ArrayList;
import java.util.Random;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import com.mobiwebcode.Sownds.VO.SowndsVO;

public class MainSounds extends Fragment implements SensorEventListener {
	LinearLayout allSoundsLinearLayout;
	ArrayList<SowndsVO> soundsList = new ArrayList<SowndsVO>();
	ArrayList<SowndsVO> currentSoundsList = new ArrayList<SowndsVO>();
	ArrayList<SowndsVO> filterSoundsList = new ArrayList<SowndsVO>();
	Animation animation = null;
	Button oldButton = null;
	RelativeLayout oldLayout;
	static MainSounds fragment = null;
	String[] colors = new String[] { "#d8774e", "#903f1c", "#b7552b",
			"#d0693c", "#cf6c42" };
	private SensorManager senSensorManager;
	private Sensor senAccelerometer;
	int ACCELEROMETER_POSITION = 1;// bottom =0 top=1 left =2 right=3
	EditText searchEditText;
	String filterText = "";
	AlertDialog alert;
	TextView tvMessage_alert;

	public static MainSounds newInstance(String content) {
		if (fragment == null)
			fragment = new MainSounds();

		return fragment;
	}

	void filterSounds(String filterText) {
		filterSoundsList = new ArrayList<SowndsVO>();
		for (int count = 0; count < soundsList.size(); count++) {
			SowndsVO svo = soundsList.get(count);
			if (svo.Anzeigename.toLowerCase()
					.contains(filterText.toLowerCase())) {
				filterSoundsList.add(svo);
			}
		}
		currentSoundsList = filterSoundsList;
		fillSoundsOnUI();
	}

	void fillSoundsOnUI() {
		allSoundsLinearLayout.removeAllViews();
		int counter = 0;
		LinearLayout vert_soundsLayout = new LinearLayout(getActivity());
		vert_soundsLayout.setOrientation(LinearLayout.VERTICAL);
		Display display = getActivity().getWindowManager().getDefaultDisplay();
		int width = display.getWidth(); // deprecated
		int height = display.getHeight(); // deprecated
		vert_soundsLayout.setLayoutParams(new LinearLayout.LayoutParams(
				(width * 40) / 100, height));
		for (int count = 0; count < currentSoundsList.size(); count++) {
			final SowndsVO svo = currentSoundsList.get(count);
			// sounds button

			final Button soundsBtn = new Button(getActivity());
			RelativeLayout.LayoutParams mainsoundLayoutParam = new RelativeLayout.LayoutParams(
					RelativeLayout.LayoutParams.MATCH_PARENT, height / 4);
			mainsoundLayoutParam.setMargins(10, 2, 2, 2);

			// causes layout

			// sound layout
			final RelativeLayout soundsBtnLayout = new RelativeLayout(
					getActivity());

			soundsBtnLayout.setLayoutParams(mainsoundLayoutParam);
			soundsBtnLayout.setPadding(5, 5, 5, 5);
			soundsBtn.setLayoutParams(new RelativeLayout.LayoutParams(
					RelativeLayout.LayoutParams.MATCH_PARENT,
					RelativeLayout.LayoutParams.MATCH_PARENT));
			soundsBtn.setGravity(Gravity.CENTER);
			soundsBtn.setBackgroundColor(svo.color);

			soundsBtn.setTextColor(Color.WHITE);
			soundsBtn.setText(svo.Anzeigename);
			soundsBtn.setId(count);
			final int var = count;

			// favorite image
			final Button favoriteImage = new Button(getActivity());
			favoriteImage.setAlpha(0.7f);
			favoriteImage.setBackgroundResource(R.drawable.star);
			favoriteImage.setGravity(Gravity.CENTER_VERTICAL);
			RelativeLayout.LayoutParams favoriteImageparams = new LayoutParams(
					50, 50);
			favoriteImageparams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
			favoriteImageparams.setMargins(5, ((height / 4) / 2) - 25, 0, 0);
			favoriteImage.setLayoutParams(favoriteImageparams);

			soundsBtn.setOnLongClickListener(new OnLongClickListener() {
				@Override
				public boolean onLongClick(View v) {
					// TODO Auto-generated method stub
					if (searchEditText.getVisibility() == View.VISIBLE) {
						searchEditText.setVisibility(View.GONE);
						InputMethodManager imm = (InputMethodManager) getActivity()
								.getSystemService(Context.INPUT_METHOD_SERVICE);
						imm.hideSoftInputFromWindow(
								searchEditText.getWindowToken(), 0);
					}
					SowndsVO oldSowndsVO = null;
					boolean sameSounds = false;
					if (Constants.isPlaying) {
						oldSowndsVO = currentSoundsList.get(oldButton.getId());
						animation.animateReverseFlip(oldButton,
								currentSoundsList.get(oldButton.getId()));
						animation.stopSound(svo, soundsBtn, favoriteImage);
						if (oldSowndsVO != null) {
							if (oldSowndsVO.Dateiname.equals(svo.Dateiname)) {
								sameSounds = true;

							}
						}
					} else if (Constants.isDownloading) {
						oldSowndsVO = currentSoundsList.get(oldButton.getId());
						animation.stopDownload(oldLayout);
						if (oldSowndsVO != null) {
							if (oldSowndsVO.Dateiname.equals(svo.Dateiname)) {
								sameSounds = true;

							}
						}
					}
					oldButton = new Button(getActivity());
					oldButton = soundsBtn;
					animation.longPressedAnimation(soundsBtn, svo,
							favoriteImage, soundsBtnLayout);
					return true;
				}
			});

			soundsBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					SowndsVO oldSowndsVO = null;
					boolean sameSounds = false;
					if (searchEditText.getVisibility() == View.VISIBLE) {
						searchEditText.setVisibility(View.GONE);
						InputMethodManager imm = (InputMethodManager) getActivity()
								.getSystemService(Context.INPUT_METHOD_SERVICE);
						imm.hideSoftInputFromWindow(
								searchEditText.getWindowToken(), 0);
					}
					if (Constants.isPlaying) {
						oldSowndsVO = currentSoundsList.get(oldButton.getId());
						animation.animateReverseFlip(oldButton,
								currentSoundsList.get(oldButton.getId()));
						animation.stopSound(svo, soundsBtn, favoriteImage);
						if (oldSowndsVO != null) {
							if (oldSowndsVO.Dateiname.equals(svo.Dateiname)) {
								sameSounds = true;
								oldButton = new Button(getActivity());
							}
						}
					} else if (Constants.isDownloading) {
						oldSowndsVO = currentSoundsList.get(oldButton.getId());
						animation.stopDownload(oldLayout);
						if (oldSowndsVO != null) {
							if (oldSowndsVO.Dateiname.equals(svo.Dateiname)) {
								sameSounds = true;
								oldButton = new Button(getActivity());
							}
						}
					}

					if (sameSounds == false) {
						oldButton = new Button(getActivity());
						oldButton = soundsBtn;
						oldLayout = new RelativeLayout(getActivity());
						oldLayout = soundsBtnLayout;
						if (animation.checkSoundExists(svo) == 1) {
							Constants.isDownloading = true;
							animation.downloadSound(svo, soundsBtnLayout,
									oldButton, favoriteImage);
						} else {
							Constants.isPlaying = true;
							animation.animateFlip(oldButton,
									currentSoundsList.get(var));
							animation.playSound(oldButton,
									currentSoundsList.get(var), favoriteImage);
						}
					}

				}
			});
			counter++;
			// vert_soundsLayout.addView(soundsImageview);

			if (svo.isFavorite == 0)
				favoriteImage.setVisibility(View.INVISIBLE);
			else
				favoriteImage.setVisibility(View.VISIBLE);
			if (svo.downloaded == 0)
				soundsBtn.setAlpha(0.5f);
			else
				soundsBtn.setAlpha(1.0f);
			soundsBtnLayout.setGravity(Gravity.CENTER_VERTICAL);
			soundsBtnLayout.addView(soundsBtn);
			soundsBtnLayout.addView(favoriteImage);
			vert_soundsLayout.addView(soundsBtnLayout);
			if (counter == 4 || count == currentSoundsList.size() - 1) {
				counter = 0;
				allSoundsLinearLayout.addView(vert_soundsLayout);
				vert_soundsLayout = new LinearLayout(getActivity());
				vert_soundsLayout.setOrientation(LinearLayout.VERTICAL);
				vert_soundsLayout
						.setLayoutParams(new LinearLayout.LayoutParams(
								(width * 40) / 100, height));
			}
		}
	}

	void readSoundsDB() {
		try {
			soundsList.clear();
			int red;
			int green;
			int blue;
			Random rn = new Random();

			Cursor cursor = null;
			cursor = Constants.SowndsDatabase.rawQuery("SELECT * FROM "
					+ Constants.TN_sounds + " where soundtype='mainsound'",
					null);
			int k = 0;
			if (cursor.getCount() > 0) {
				while (cursor.moveToNext()) {
					red = 216;// rn.nextInt(200 - 160) + 160;
					blue = 78;// rn.nextInt(80 - 40) + 20;
					green = 119;// rn.nextInt(130 - 80) + 60;
					SowndsVO svo = new SowndsVO();
					String colorString = colors[new Random()
							.nextInt(colors.length)];

					if (colorString.equals("#d8774e"))
						svo.resourceImageColor = R.drawable.color1;
					else if (colorString.equals("#903f1c"))
						svo.resourceImageColor = R.drawable.color2;
					else if (colorString.equals("#b7552b"))
						svo.resourceImageColor = R.drawable.color3;
					else if (colorString.equals("#d0693c"))
						svo.resourceImageColor = R.drawable.color4;
					else if (colorString.equals("#cf6c42"))
						svo.resourceImageColor = R.drawable.color5;

					int color = Color.parseColor(colorString);
					svo.soundid = cursor.getInt(cursor
							.getColumnIndex("soundid"));
					svo.Dateiname = cursor.getString(cursor
							.getColumnIndex("filename"));
					svo.isFavorite = cursor.getInt(cursor
							.getColumnIndex("isfavorite"));
					svo.downloaded = cursor.getInt(cursor
							.getColumnIndex("downloaded"));
					svo.Anzeigename = cursor.getString(cursor
							.getColumnIndex("Anzeigename"));
					svo.Eventbased = cursor.getString(cursor
							.getColumnIndex("Eventbased"));
					svo.Eventstartdate = cursor.getString(cursor
							.getColumnIndex("Eventstartdate"));
					svo.Eventenddate = cursor.getString(cursor
							.getColumnIndex("Eventenddate"));
					svo.Eventenddate = cursor.getString(cursor
							.getColumnIndex("Eventenddate"));
					svo.soundtype = cursor.getString(cursor
							.getColumnIndex("soundtype"));
					svo.color = color;
					soundsList.add(svo);
				}
			}
			cursor.close();
			currentSoundsList = soundsList;
			fillSoundsOnUI();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		animation = Animation.newInstance(getActivity());

		View layoutView = inflater.inflate(R.layout.main_sounds, container,
				false);

		tvMessage_alert = new TextView(getActivity());

		alert = new AlertDialog.Builder(getActivity())
				.setView(tvMessage_alert)
				.setTitle(
						getActivity().getResources().getString(
								R.string.download_all_sounds))
				.setPositiveButton(
						getActivity().getResources().getString(
								R.string.download_all_sounds), null) // Set to
																		// null.
																		// We
																		// override
																		// the
																		// onclick
				.setNegativeButton(
						getActivity().getResources().getString(
								R.string.resume_later), null).create();
		searchEditText = (EditText) layoutView
				.findViewById(R.id.searchEditText);
		searchEditText.addTextChangedListener(new TextWatcher() {

			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				if (s.length() == 0) { // do your work here }
					if (currentSoundsList != soundsList) {
						currentSoundsList = soundsList;
						fillSoundsOnUI();
					}
				}

			}

			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {

			}

			public void afterTextChanged(Editable s) {

			}
		});

		searchEditText.setOnEditorActionListener(new OnEditorActionListener() {

			@Override
			public boolean onEditorAction(TextView v, int actionId,
					KeyEvent event) {
				// TODO Auto-generated method stub
				if ((event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER))
						|| (actionId == EditorInfo.IME_ACTION_SEARCH))
					searchEditText.setVisibility(View.GONE);
				filterText = searchEditText.getText().toString();
				if (!searchEditText.getText().toString().equals("")) {
					filterSounds(searchEditText.getText().toString());
				} else {
					currentSoundsList = soundsList;
					fillSoundsOnUI();
				}
				InputMethodManager imm = (InputMethodManager) getActivity()
						.getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
				return false;
			}
		});
		allSoundsLinearLayout = (LinearLayout) layoutView
				.findViewById(R.id.mainLayout);
		readSoundsDB();

		senSensorManager = (SensorManager) getActivity().getSystemService(
				Context.SENSOR_SERVICE);
		senAccelerometer = senSensorManager
				.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		senSensorManager.registerListener(this, senAccelerometer,
				SensorManager.SENSOR_DELAY_NORMAL);

		return layoutView;
	}

	void downloadAll() {
		alert.show();

		final Button positive = alert.getButton(AlertDialog.BUTTON_POSITIVE);
		final Button negative = alert.getButton(AlertDialog.BUTTON_NEGATIVE);
		positive.setText(getActivity().getResources().getString(
				R.string.download_all_sounds));
		negative.setText(getActivity().getResources().getString(
				R.string.resume_later));
		tvMessage_alert.setText(getActivity().getResources().getString(
				R.string.click_on_download_all_to_download_all_the_sounds));
		positive.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View view) {
				positive.setText(getActivity().getResources().getString(
						R.string.downloading_sounds__));
				animation.interruptedAllDownload = false;
				animation.downloadAllSounds(soundsList, tvMessage_alert);
			}
		});

		negative.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				animation.stopDownloadAllSounds();
				fillSoundsOnUI();
				alert.dismiss();
			}
		});
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onResume() {
		super.onResume();
		senSensorManager.registerListener(this, senAccelerometer,
				SensorManager.SENSOR_DELAY_NORMAL);
	}

	@Override
	public void onPause() {
		super.onPause();
		senSensorManager.unregisterListener(this);
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		// TODO Auto-generated method stub
		Sensor mySensor = event.sensor;

		if (mySensor.getType() == Sensor.TYPE_ACCELEROMETER) {
			float x = event.values[0];
			float y = event.values[1];
			float z = event.values[2];
			if (Math.abs(x) > Math.abs(y)) {
				if (x < 0) {
					if (ACCELEROMETER_POSITION != 3) {
						// System.out.println("right");
					}
					// ACCELEROMETER_POSITION = 3;
				}
				if (x > 0) {

					if (ACCELEROMETER_POSITION != 2) {
						// System.out.println("left");
					}
					// ACCELEROMETER_POSITION = 2;
				}
			} else {
				Display display = getActivity().getWindowManager()
						.getDefaultDisplay();
				int height = display.getHeight(); // deprecated
				if (y < -6.5) {
					System.out.println("top");
					searchEditText.setVisibility(View.VISIBLE);
					if (searchEditText.getText().toString().equals(""))
						searchEditText.setText(filterText);
					searchEditText.setSelection(searchEditText.getText()
							.length());
					searchEditText.requestFocus();
					InputMethodManager imm = (InputMethodManager) getActivity()
							.getSystemService(Context.INPUT_METHOD_SERVICE);
					imm.showSoftInput(searchEditText,
							InputMethodManager.SHOW_IMPLICIT);
				} else if (y > 9) {
					System.out.println("bottom");
					if (!alert.isShowing())
						downloadAll();
				}
			}
		}
	}

}
