package com.mobiwebcode.Sownds.VO;

public class SowndsVO {
	public int soundid = 0;
	public String Dateiname = "", Anzeigename = "", Eventbased = "",
			Eventstartdate = "", Eventenddate = "", soundtype = "";
	public int isFavorite = 0, downloaded = 0;
	public int color;
	public int resourceImageColor;
	public int isFlipped = 0, isPlaying = 0;
}
