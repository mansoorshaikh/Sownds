package com.mobiwebcode.Sownds;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Random;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.DialogInterface.OnShowListener;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.MediaRecorder.OnInfoListener;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;

import com.mobiwebcode.Sownds.VO.SowndsVO;

public class YourSounds extends Fragment implements OnTouchListener {
	// new recording variables
	private static final int RECORDER_BPP = 16;
	// private static final String AUDIO_RECORDER_FILE_EXT_WAV = ".wav";
	private static final String AUDIO_RECORDER_FOLDER = "Sownds";
	private static final String AUDIO_RECORDER_TEMP_FILE = "record_temp.raw";
	private static int frequency = 22050;
	private static int channelConfiguration = AudioFormat.CHANNEL_IN_MONO;
	private static int EncodingBitRate = AudioFormat.ENCODING_PCM_16BIT;
	private AudioRecord audioRecord = null;
	private int recBufSize = 0;
	private Thread recordingThread = null;
	public boolean isRecording = false;

	LinearLayout recordedSoundsLinearLayout;
	ArrayList<SowndsVO> recordedSoundsList = new ArrayList<SowndsVO>();
	Animation animation = null;
	Button oldButton = null, recordButton = null;
	RelativeLayout oldLayout;
	LinearLayout vert_soundsLayout;
	HorizontalScrollView horscrollview;
	int recording = 0;
	static YourSounds fragment = null;

	private void copyDataBase() {
		byte[] buffer = new byte[1024];
		OutputStream myOutput = null;
		int length;
		InputStream myInput = null;
		try {
			File f = new File(Constants.DB_PATH);
			if (!f.exists()) {
				f.mkdir();
				myInput = getActivity().getAssets().open("sownds.db");
				myOutput = new FileOutputStream(Constants.DB_PATH
						+ Constants.DB_NAME);
				while ((length = myInput.read(buffer)) > 0) {
					myOutput.write(buffer, 0, length);
				}
				myOutput.close();
				myOutput.flush();

				myInput.close();

				// parse main sounds and add them to db
			}
			readSoundsDB();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		animation = Animation.newInstance(getActivity());
		View layoutView = inflater.inflate(R.layout.your_sounds, container,
				false);
		recordedSoundsLinearLayout = (LinearLayout) layoutView
				.findViewById(R.id.mainLayout);
		horscrollview = (HorizontalScrollView) layoutView
				.findViewById(R.id.horscrollview);
		File folder = new File(Environment.getExternalStorageDirectory()
				+ "/Sownds/");
		if (!folder.exists())
			folder.mkdir();

		copyDataBase();

		return layoutView;
	}

	public static YourSounds newInstance(String content) {
		if (fragment == null)
			fragment = new YourSounds();
		return fragment;
	}

	void readSoundsDB() {
		try {
			recordedSoundsList.clear();
			Constants.SowndsDatabase = SQLiteDatabase.openDatabase(
					Constants.path, null, SQLiteDatabase.OPEN_READWRITE);
			int red;
			int green;
			int blue;
			Random rn = new Random();
			Cursor cursor = null;
			cursor = Constants.SowndsDatabase.rawQuery("SELECT * FROM "
					+ Constants.TN_sounds + " where soundtype='recordedsound'",
					null);
			int color = Color.rgb(100, 149, 237);
			int k = 0;
			if (cursor.getCount() > 0) {
				while (cursor.moveToNext()) {
					SowndsVO svo = new SowndsVO();
					svo.resourceImageColor = R.drawable.color6;
					svo.soundid = cursor.getInt(cursor
							.getColumnIndex("soundid"));
					svo.Dateiname = cursor.getString(cursor
							.getColumnIndex("filename"));
					svo.isFavorite = cursor.getInt(cursor
							.getColumnIndex("isfavorite"));
					svo.downloaded = cursor.getInt(cursor
							.getColumnIndex("downloaded"));
					svo.Anzeigename = cursor.getString(cursor
							.getColumnIndex("Anzeigename"));
					svo.Eventbased = cursor.getString(cursor
							.getColumnIndex("Eventbased"));
					svo.Eventstartdate = cursor.getString(cursor
							.getColumnIndex("Eventstartdate"));
					svo.Eventenddate = cursor.getString(cursor
							.getColumnIndex("Eventenddate"));
					svo.soundtype = cursor.getString(cursor
							.getColumnIndex("soundtype"));
					svo.color = color;
					recordedSoundsList.add(svo);
				}
			}
			cursor.close();
			SowndsVO plusSoundVO = new SowndsVO();
			plusSoundVO.Anzeigename = "+";
			plusSoundVO.color = color;
			recordedSoundsList.add(plusSoundVO);
			fillSoundsOnUI();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	void fillSoundsOnUI() {
		int counter = 0;
		recordedSoundsLinearLayout.removeAllViews();
		vert_soundsLayout = new LinearLayout(getActivity());
		vert_soundsLayout.setOrientation(LinearLayout.VERTICAL);
		Display display = getActivity().getWindowManager().getDefaultDisplay();
		int width = display.getWidth(); // deprecated
		int height = display.getHeight(); // deprecated

		vert_soundsLayout.setLayoutParams(new LinearLayout.LayoutParams(
				(width * 40) / 100, height));

		for (int count = 0; count < recordedSoundsList.size(); count++) {
			final SowndsVO svo = recordedSoundsList.get(count);

			// sounds button
			final Button soundsBtn = new Button(getActivity());
			RelativeLayout.LayoutParams mainsoundLayoutParam = new RelativeLayout.LayoutParams(
					RelativeLayout.LayoutParams.MATCH_PARENT, height / 4);
			mainsoundLayoutParam.setMargins(2, 2, 2, 2);

			// favorite image
			final Button favoriteImage = new Button(getActivity());
			favoriteImage.setAlpha(0.7f);
			favoriteImage.setBackgroundResource(R.drawable.star);
			favoriteImage.setGravity(Gravity.CENTER_VERTICAL);
			RelativeLayout.LayoutParams favoriteImageparams = new LayoutParams(
					50, 50);
			favoriteImageparams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
			favoriteImageparams.setMargins(5, ((height / 4) / 2) - 25, 0, 0);
			favoriteImage.setLayoutParams(favoriteImageparams); // causes layout

			// sound layout
			final RelativeLayout soundsBtnLayout = new RelativeLayout(
					getActivity());

			soundsBtnLayout.setLayoutParams(mainsoundLayoutParam);
			soundsBtnLayout.setPadding(5, 5, 5, 5);
			soundsBtn.setLayoutParams(new RelativeLayout.LayoutParams(
					RelativeLayout.LayoutParams.MATCH_PARENT,
					RelativeLayout.LayoutParams.MATCH_PARENT));
			soundsBtn.setGravity(Gravity.CENTER);
			soundsBtn.setBackgroundColor(svo.color);
			soundsBtn.setAlpha(1.0f);
			soundsBtn.setTextColor(Color.WHITE);
			soundsBtn.setText(svo.Anzeigename);
			soundsBtn.setId(count);
			final int var = count;

			if (count == recordedSoundsList.size() - 1) {
				recordButton = soundsBtn;
				recordButton.setOnTouchListener(this);
			} else {
				soundsBtn.setOnLongClickListener(new OnLongClickListener() {
					@Override
					public boolean onLongClick(View v) {
						// TODO Auto-generated method stub
						if (isRecording == true) {
							saveRecording();
						} else {
							SowndsVO oldSowndsVO = null;
							boolean sameSounds = false;
							if (Constants.isPlaying) {
								oldSowndsVO = recordedSoundsList.get(oldButton
										.getId());
								animation.animateReverseFlip(oldButton,
										recordedSoundsList.get(oldButton
												.getId()));
								animation.stopSound(svo, soundsBtn,
										favoriteImage);
								if (oldSowndsVO != null) {
									if (oldSowndsVO.Dateiname
											.equals(svo.Dateiname)) {
										sameSounds = true;
									}
								}
							}
							oldButton = new Button(getActivity());
							oldButton = soundsBtn;
							animation.longPressedAnimation(soundsBtn, svo,
									favoriteImage, soundsBtnLayout);

						}
						return true;
					}
				});
			}

			if (count != recordedSoundsList.size() - 1) {
				soundsBtn.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						if (isRecording == true) {
							saveRecording();
						} else {
							SowndsVO oldSowndsVO = null;
							boolean sameSounds = false;
							if (Constants.isPlaying) {
								oldSowndsVO = recordedSoundsList.get(oldButton
										.getId());
								animation.animateReverseFlip(oldButton,
										recordedSoundsList.get(oldButton
												.getId()));
								animation.stopSound(svo, soundsBtn,
										favoriteImage);
								if (oldSowndsVO != null) {
									if (oldSowndsVO.Dateiname
											.equals(svo.Dateiname)) {
										sameSounds = true;
										oldButton = new Button(getActivity());
									}
								}
							}

							if (sameSounds == false) {
								oldButton = new Button(getActivity());
								oldButton = soundsBtn;
								oldLayout = new RelativeLayout(getActivity());
								oldLayout = soundsBtnLayout;

								Constants.isPlaying = true;
								animation.animateFlip(oldButton,
										recordedSoundsList.get(var));
								animation.playSound(oldButton,
										recordedSoundsList.get(var),
										favoriteImage);

							}

						}
					}
				});
			}
			counter++;

			if (svo.isFavorite == 0)
				favoriteImage.setVisibility(View.INVISIBLE);
			else
				favoriteImage.setVisibility(View.VISIBLE);

			soundsBtnLayout.addView(soundsBtn);
			soundsBtnLayout.addView(favoriteImage);
			vert_soundsLayout.addView(soundsBtnLayout);
			if (count == recordedSoundsList.size() - 1 && counter != 4) {
				counter = 0;
				vert_soundsLayout.setId(100 + count);
				recordedSoundsLinearLayout.addView(vert_soundsLayout);
			} else if (counter == 4) {
				counter = 0;
				vert_soundsLayout.setId(100 + count);
				recordedSoundsLinearLayout.addView(vert_soundsLayout);
				vert_soundsLayout = new LinearLayout(getActivity());
				vert_soundsLayout.setOrientation(LinearLayout.VERTICAL);
				vert_soundsLayout
						.setLayoutParams(new LinearLayout.LayoutParams(
								(width * 40) / 100, height));
			}
		}
	}

	public boolean onTouch(View v, MotionEvent event) {
		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			if (v.getId() == recordButton.getId())
				try {
					if (isRecording == false) {
						startRecord();
					} else if (isRecording == true) {
						saveRecording();
					}
				} catch (Exception e) {
					// TODO: handle exception
				}

			return true;
		}
		return false;
	}

	// Recording File Methods

	private void startRecord() {
		recordButton.setText(getActivity().getResources().getString(
				R.string.recording));
		recordButton.setBackgroundColor(Color.RED);
		createAudioRecord();
		audioRecord.startRecording();

		isRecording = true;

		recordingThread = new Thread(new Runnable() {
			public void run() {
				writeAudioDataToFile();
			}
		}, "AudioRecorder Thread");

		recordingThread.start();
	}

	private void writeAudioDataToFile() {
		byte data[] = new byte[recBufSize];
		String filename = getTempFilename();
		FileOutputStream os = null;

		try {
			os = new FileOutputStream(filename);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int read = 0;

		if (null != os) {
			while (isRecording) {
				read = audioRecord.read(data, 0, recBufSize);

				if (AudioRecord.ERROR_INVALID_OPERATION != read) {
					try {
						os.write(data);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}

			try {
				os.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public void saveRecording() {
		if (null != audioRecord) {
			isRecording = false;

			audioRecord.stop();
			audioRecord.release();

			audioRecord = null;
			recordingThread = null;
		}

		recordButton.setText("+");
		recordButton.setBackgroundColor(Color.rgb(100, 149, 237));

		final AlertDialog d = new AlertDialog.Builder(getActivity())
				.setTitle(
						getActivity().getResources().getString(
								R.string.recording_was_successful))
				.setMessage(
						getActivity().getResources().getString(
								R.string.please_name_your_recorded_sound_now))
				.setPositiveButton(
						getActivity().getResources().getString(
								R.string.delete_sound), null)
				.setNegativeButton(
						getActivity().getResources().getString(
								R.string.save_sound), null).create();

		final EditText input = new EditText(getActivity());
		d.setView(input);

		d.setOnShowListener(new OnShowListener() {

			@Override
			public void onShow(DialogInterface dialog) {
				// TODO Auto-generated method stub
				Button b = d.getButton(AlertDialog.BUTTON_POSITIVE);
				b.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						deleteTempFile();
						d.dismiss();
					}
				});

				Button b_negative = d.getButton(AlertDialog.BUTTON_NEGATIVE);

				b_negative.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						String value = input.getText().toString();
						if (value.equals("")) {

						} else {
							d.dismiss();
							copyWaveFile(getTempFilename(), Environment
									.getExternalStorageDirectory()
									.getAbsolutePath()
									+ "/Sownds/" + value + ".wav");
							deleteTempFile();
							ContentValues values = new ContentValues();
							values.put("filename", value + ".wav");
							values.put("Anzeigename", value);
							values.put("soundtype", "recordedsound");
							values.put("isfavorite", 0);
							Constants.SowndsDatabase.insert(
									Constants.TN_sounds, null, values);
							readSoundsDB();

						}
					}
				});
			}
		});
		d.show();
	}

	private void deleteTempFile() {
		File file = new File(getTempFilename());

		file.delete();
	}

	private void copyWaveFile(String inFilename, String outFilename) {
		FileInputStream in = null;
		FileOutputStream out = null;
		long totalAudioLen = 0;
		long totalDataLen = totalAudioLen + 36;
		long longSampleRate = frequency;
		int channels = 1;
		long byteRate = RECORDER_BPP * frequency * channels / 8;

		byte[] data = new byte[recBufSize];

		try {
			in = new FileInputStream(inFilename);
			out = new FileOutputStream(outFilename);
			totalAudioLen = in.getChannel().size();
			totalDataLen = totalAudioLen + 36;

			// AppLog.logString("File size: " + totalDataLen);

			WriteWaveFileHeader(out, totalAudioLen, totalDataLen,
					longSampleRate, channels, byteRate);

			while (in.read(data) != -1) {
				out.write(data);
			}

			in.close();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void WriteWaveFileHeader(FileOutputStream out, long totalAudioLen,
			long totalDataLen, long longSampleRate, int channels, long byteRate)
			throws IOException {

		byte[] header = new byte[44];

		header[0] = 'R'; // RIFF/WAVE header
		header[1] = 'I';
		header[2] = 'F';
		header[3] = 'F';
		header[4] = (byte) (totalDataLen & 0xff);
		header[5] = (byte) ((totalDataLen >> 8) & 0xff);
		header[6] = (byte) ((totalDataLen >> 16) & 0xff);
		header[7] = (byte) ((totalDataLen >> 24) & 0xff);
		header[8] = 'W';
		header[9] = 'A';
		header[10] = 'V';
		header[11] = 'E';
		header[12] = 'f'; // 'fmt ' chunk
		header[13] = 'm';
		header[14] = 't';
		header[15] = ' ';
		header[16] = 16; // 4 bytes: size of 'fmt ' chunk
		header[17] = 0;
		header[18] = 0;
		header[19] = 0;
		header[20] = 1; // format = 1
		header[21] = 0;
		header[22] = (byte) channels;
		header[23] = 0;
		header[24] = (byte) (longSampleRate & 0xff);
		header[25] = (byte) ((longSampleRate >> 8) & 0xff);
		header[26] = (byte) ((longSampleRate >> 16) & 0xff);
		header[27] = (byte) ((longSampleRate >> 24) & 0xff);
		header[28] = (byte) (byteRate & 0xff);
		header[29] = (byte) ((byteRate >> 8) & 0xff);
		header[30] = (byte) ((byteRate >> 16) & 0xff);
		header[31] = (byte) ((byteRate >> 24) & 0xff);
		header[32] = (byte) (1 * 16 / 8); // block align
		header[33] = 0;
		header[34] = RECORDER_BPP; // bits per sample
		header[35] = 0;
		header[36] = 'd';
		header[37] = 'a';
		header[38] = 't';
		header[39] = 'a';
		header[40] = (byte) (totalAudioLen & 0xff);
		header[41] = (byte) ((totalAudioLen >> 8) & 0xff);
		header[42] = (byte) ((totalAudioLen >> 16) & 0xff);
		header[43] = (byte) ((totalAudioLen >> 24) & 0xff);
		out.write(header, 0, 44);
	}

	public void createAudioRecord() {
		recBufSize = AudioRecord.getMinBufferSize(frequency,
				channelConfiguration, EncodingBitRate);

		audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, frequency,
				channelConfiguration, EncodingBitRate, recBufSize);
	}

	private String getFilename() {
		String filepath = Environment.getExternalStorageDirectory()
				.getAbsolutePath();
		File file = new File(filepath, AUDIO_RECORDER_FOLDER);

		if (file.exists()) {
			file.delete();
		}

		return (file.getAbsolutePath() + "/speaker.wav");
	}

	private String getTempFilename() {
		String filepath = Environment.getExternalStorageDirectory().getPath();
		File file = new File(filepath, AUDIO_RECORDER_FOLDER);

		if (!file.exists()) {
			file.mkdirs();
		}

		File tempFile = new File(filepath, AUDIO_RECORDER_TEMP_FILE);

		if (tempFile.exists())
			tempFile.delete();

		return (file.getAbsolutePath() + "/" + AUDIO_RECORDER_TEMP_FILE);
	}

}
