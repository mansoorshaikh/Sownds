package com.mobiwebcode.Sownds;

import android.database.sqlite.SQLiteDatabase;

public class Constants {
	public static boolean isPlaying = false, isDownloading = false;
	public static SQLiteDatabase SowndsDatabase;
	public static String DB_PATH = "/data/data/com.mobiwebcode.Sownds/databases/";
	public static final String DB_NAME = "sownds.db";
	public static String path = DB_PATH + DB_NAME;
	public static String TN_sounds = "sounds";
	public static boolean isFromFavorite = false;
}
