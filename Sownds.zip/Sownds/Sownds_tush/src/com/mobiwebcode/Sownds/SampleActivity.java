package com.mobiwebcode.Sownds;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.animation.AlphaAnimation;
import android.widget.Toast;

import com.directionalviewpager.DirectionalViewPager;

public class SampleActivity extends FragmentActivity implements
		NavigateViewInterface {
	DirectionalViewPager pager;

	public void onBackPressed() {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.addCategory(Intent.CATEGORY_HOME);
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		startActivity(intent);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Set up the pager
		pager = (DirectionalViewPager) findViewById(R.id.pager);
		pager.setOrientation(DirectionalViewPager.VERTICAL);
		pager.setAdapter(new TestFragmentAdapter(getSupportFragmentManager()));
		pager.setCurrentItem(1);

		pager.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageSelected(int arg0) {
				// TODO Auto-generated method stub
				Animation animation = Animation
						.newInstance(SampleActivity.this);

				if (arg0 == 0) {
					YourSounds.newInstance("").fillSoundsOnUI();
					if (MainSounds.newInstance("").oldButton != null) {
						if (MainSounds.newInstance("").oldButton.getId() != -1)

							animation.animateReverseFlip(MainSounds
									.newInstance("").oldButton, MainSounds
									.newInstance("").soundsList.get(MainSounds
									.newInstance("").oldButton.getId()));
					}
				} else if (arg0 == 1) {
					if (YourSounds.newInstance("").isRecording == true) {
						YourSounds.newInstance("").saveRecording();
					}
					if (FavoriteSounds.newInstance("").oldButton != null) {
						if (FavoriteSounds.newInstance("").favoriteSoundsList
								.size() > 0
								&& FavoriteSounds.newInstance("").oldButton
										.getId() > FavoriteSounds
										.newInstance("").favoriteSoundsList
										.size())
							animation.animateReverseFlip(
									FavoriteSounds.newInstance("").oldButton,
									FavoriteSounds.newInstance("").favoriteSoundsList
											.get(FavoriteSounds.newInstance("").oldButton
													.getId()));
					}
					if (YourSounds.newInstance("").oldButton != null) {
						if (YourSounds.newInstance("").recordedSoundsList
								.size() > 0
								&& YourSounds.newInstance("").oldButton.getId() > YourSounds
										.newInstance("").recordedSoundsList
										.size())
							animation.animateReverseFlip(YourSounds
									.newInstance("").oldButton, YourSounds
									.newInstance("").recordedSoundsList
									.get(YourSounds.newInstance("").oldButton
											.getId()));
					}
				}
				if (arg0 == 2) {
					if (FavoriteSounds.newInstance("").readSoundsDB() == 0) {
						Toast.makeText(getApplicationContext(),
								R.string.no_favorites_added, Toast.LENGTH_LONG)
								.show();

						if (Constants.isPlaying) {
							if (MainSounds.newInstance("").oldButton != null) {
								if (MainSounds.newInstance("").oldButton
										.getId() != -1)
									animation.stopSound(null, null, null);
								animation.animateReverseFlip(
										MainSounds.newInstance("").oldButton,
										MainSounds.newInstance("").soundsList
												.get(MainSounds.newInstance("").oldButton
														.getId()));
							}
						}
						pager.setCurrentItem(1);
					} else {
						if (MainSounds.newInstance("").oldButton != null) {
							if (MainSounds.newInstance("").oldButton.getId() != -1)
								animation.animateReverseFlip(
										MainSounds.newInstance("").oldButton,
										MainSounds.newInstance("").soundsList
												.get(MainSounds.newInstance("").oldButton
														.getId()));
						}
						FavoriteSounds.newInstance("").fillSoundsOnUI();
					}
				}
				animation.stopSound(null, null, null);
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				AlphaAnimation animation1 = new AlphaAnimation(0.6f, 1.0f);
				animation1.setDuration(80);
				animation1.setStartOffset(100);
				animation1.setFillAfter(true);
				pager.startAnimation(animation1);
			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
				// TODO Auto-generated method stub

			}
		});
	}

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// super.onSaveInstanceState(outState);
	}

	@Override
	public void navigate() {
		// TODO Auto-generated method stub
		Toast.makeText(getApplicationContext(), "inside navigate",
				Toast.LENGTH_LONG).show();
		pager.setCurrentItem(1);
	}
}
