package com.mobiwebcode.Sownds;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.view.View;

class TestFragmentAdapter extends FragmentStatePagerAdapter {
	protected static final String[] CONTENT = new String[] { "This", "Is Is",
			"A A A", "Test", };

	public TestFragmentAdapter(FragmentManager fm) {
		super(fm);
	}

	@Override
	public Fragment getItem(int position) {
		switch (position) {
		case 0:
			return YourSounds.newInstance("");

		case 1:
			return MainSounds.newInstance("");

		case 2:
			return FavoriteSounds.newInstance("");
		}
		return null;

	}

	@Override
	public void destroyItem(View container, int position, Object object) {
		// TODO Auto-generated method stub
		super.destroyItem(container, position, object);
	}

	@Override
	public int getCount() {
		return 3;
	}

	@Override
	public int getItemPosition(Object object) {
		return POSITION_NONE;
	}

	@Override
	public Object instantiateItem(View container, int position) {
		// TODO Auto-generated method stub
		return super.instantiateItem(container, position);
	}
}