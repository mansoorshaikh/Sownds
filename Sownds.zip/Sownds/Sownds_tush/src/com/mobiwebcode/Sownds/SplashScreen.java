package com.mobiwebcode.Sownds;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;

public class SplashScreen extends Activity {
	private static final int SWIPE_MIN_DISTANCE = 120;
	private static final int SWIPE_MAX_OFF_PATH = 250;
	private static final int SWIPE_THRESHOLD_VELOCITY = 200;
	private GestureDetector gestureDetector;
	View.OnTouchListener gestureListener;
	LinearLayout mainLinearLayout = null;
	int counter = 0;
	int images[] = { R.drawable.slide1, R.drawable.slide2, R.drawable.slide3,
			R.drawable.slide4, R.drawable.slide5 };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		SharedPreferences myPrefs = this.getSharedPreferences("myPrefs",
				MODE_WORLD_READABLE);
		String prefName = myPrefs.getString("finish", "");
		if (prefName.equals("yes")) {
			Intent intent = new Intent(SplashScreen.this, SampleActivity.class);
			startActivity(intent);
		} else {
			setContentView(R.layout.spash_screen);
			mainLinearLayout = (LinearLayout) findViewById(R.id.mainLinearLayout);

			gestureDetector = new GestureDetector(this, new MyGestureDetector());
			gestureListener = new View.OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					return gestureDetector.onTouchEvent(event);
				}
			};
			mainLinearLayout.setOnTouchListener(gestureListener);
		}
	}

	class MyGestureDetector extends SimpleOnGestureListener {
		@Override
		public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
				float velocityY) {
			try {
				if (Math.abs(e1.getY() - e2.getY()) > SWIPE_MAX_OFF_PATH)
					return false;
				// right to left swipe
				if (e1.getX() - e2.getX() > SWIPE_MIN_DISTANCE
						&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
					if (counter <= 3) {
						counter++;
						mainLinearLayout.setBackgroundResource(images[counter]);
					} else {
						SharedPreferences myPrefs = SplashScreen.this
								.getSharedPreferences("myPrefs",
										MODE_WORLD_READABLE);
						SharedPreferences.Editor prefsEditor = myPrefs.edit();
						prefsEditor.putString("finish", "yes");
						prefsEditor.commit();
						Intent intent = new Intent(SplashScreen.this,
								SampleActivity.class);
						startActivity(intent);
					}
				} else if (e2.getX() - e1.getX() > SWIPE_MIN_DISTANCE
						&& Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY) {
					if (counter > 0) {
						counter--;
						mainLinearLayout.setBackgroundResource(images[counter]);
					}
				}
			} catch (Exception e) {
				// nothing
			}
			return false;
		}

		@Override
		public boolean onDown(MotionEvent e) {
			return true;
		}
	}

}
