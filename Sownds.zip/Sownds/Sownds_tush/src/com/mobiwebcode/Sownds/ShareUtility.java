package com.mobiwebcode.Sownds;

import java.io.File;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Toast;

import com.mobiwebcode.Sownds.VO.SowndsVO;

public class ShareUtility {
	String STORAGE_PATH = "/Sownds/";
	Activity mContext = null;

	public ShareUtility(Activity context) {
		// TODO Auto-generated constructor stub
		mContext = context;
	}

	void shareSoundOnSocialMedia(SowndsVO svo, Activity context) {
		Intent share = new Intent(Intent.ACTION_SEND);
		share.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		share.setType("audio/*");
		String filePath = Environment.getExternalStorageDirectory()
				+ STORAGE_PATH + svo.Dateiname.replace(" ", "%20");
		if (svo.soundtype.equals("mainsound")) {
			filePath = filePath + ".mp3";
		}
		share.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File(filePath)));

		context.startActivity(Intent.createChooser(share, "Share Sound File"));

	}

	void setSoundAsRingtone(SowndsVO svo, Activity context) {
		String filePath = Environment.getExternalStorageDirectory()
				+ "/Sownds/" + svo.Dateiname.replace(" ", "%20");
		if (svo.soundtype.equals("mainsound")) {
			filePath = filePath + ".mp3";
		}
		File k = new File(filePath);
		ContentValues values = new ContentValues();
		values.put(MediaStore.MediaColumns.DATA, k.getAbsolutePath());
		values.put(MediaStore.MediaColumns.TITLE, svo.Anzeigename);
		values.put(MediaStore.MediaColumns.MIME_TYPE, "audio/*");
		values.put(MediaStore.Audio.Media.IS_RINGTONE, true);

		Uri uri = MediaStore.Audio.Media.getContentUriForPath(k
				.getAbsolutePath());
		Uri newUri = context.getContentResolver().insert(uri, values);
		RingtoneManager.setActualDefaultRingtoneUri(context,
				RingtoneManager.TYPE_RINGTONE, newUri);

	}

	void reportSound(SowndsVO svo, Activity context) {

		Intent i = new Intent(Intent.ACTION_SEND);
		i.setType("message/rfc822");
		i.putExtra(Intent.EXTRA_EMAIL,
				new String[] { "mail@dimitristaufer.com" });
		i.putExtra(Intent.EXTRA_SUBJECT, "Report Problem sownds");
		i.putExtra(Intent.EXTRA_TEXT, "There is a problem in " + svo.Dateiname
				+ " Sound. Please check on it.");
		try {
			mContext.startActivity(Intent.createChooser(i, "Send mail..."));
		} catch (android.content.ActivityNotFoundException ex) {
			Toast.makeText(mContext, "There are no email clients installed.",
					Toast.LENGTH_SHORT).show();
		}

	}
}
