package com.mobiwebcode.Sownds;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;

import com.mobiwebcode.Sownds.VO.SowndsVO;

public class DBHelper {
	String STORAGE_PATH = "/Sownds/";
	Activity mContext = null;

	public DBHelper(Activity context) {
		// TODO Auto-generated constructor stub
		mContext = context;
	}

	void addToFavorite(SowndsVO svo) {

		ContentValues values = new ContentValues();
		values.put("isfavorite", 1);

		Constants.SowndsDatabase.update(Constants.TN_sounds, values, "soundid"
				+ "=" + svo.soundid, null);
		svo.isFavorite = 1;
	}

	void removeFromFavorites(SowndsVO svo) {
		ContentValues values = new ContentValues();
		values.put("isfavorite", 0);

		Constants.SowndsDatabase.update(Constants.TN_sounds, values, "soundid"
				+ "=" + svo.soundid, null);
		svo.isFavorite = 0;

	}

	void updateDownloadStatus(SowndsVO svo) {
		ContentValues values = new ContentValues();
		values.put("downloaded", 1);

		Constants.SowndsDatabase.update(Constants.TN_sounds, values, "soundid"
				+ "=" + svo.soundid, null);
	}

	void deleteSound(SowndsVO svo) {
		Constants.SowndsDatabase.delete(Constants.TN_sounds, "soundid" + "="
				+ svo.soundid, null);
		YourSounds.newInstance("").readSoundsDB();
		if (FavoriteSounds.newInstance("").readSoundsDB() == 0) {
			
		}
	}
}