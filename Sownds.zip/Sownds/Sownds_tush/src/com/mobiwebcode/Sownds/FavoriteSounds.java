package com.mobiwebcode.Sownds;

import java.util.ArrayList;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;

import com.mobiwebcode.Sownds.VO.SowndsVO;

public class FavoriteSounds extends Fragment {
	LinearLayout favoriteSoundsLinearLayout;
	static FavoriteSounds fragment = null;
	ArrayList<SowndsVO> favoriteSoundsList = new ArrayList<SowndsVO>();
	Animation animation = null;
	Button oldButton = null;
	RelativeLayout oldLayout;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		animation = Animation.newInstance(getActivity());
		View layoutView = inflater.inflate(R.layout.your_sounds, container,
				false);
		favoriteSoundsLinearLayout = (LinearLayout) layoutView
				.findViewById(R.id.mainLayout);
		readSoundsDB();
		return layoutView;
	}

	public static FavoriteSounds newInstance(String content) {
		if (fragment == null)
			fragment = new FavoriteSounds();
		return fragment;
	}

	int readSoundsDB() {
		int cursorCount = 0;
		try {
			favoriteSoundsList.clear();
			int color = Color.rgb(50, 150, 50);
			Cursor cursor = null;
			cursor = Constants.SowndsDatabase.rawQuery("SELECT * FROM "
					+ Constants.TN_sounds + " where isfavorite=1", null);
			int k = 0;
			if (cursor.getCount() > 0) {
				while (cursor.moveToNext()) {
					SowndsVO svo = new SowndsVO();
					svo.resourceImageColor = R.drawable.color7;
					svo.soundid = cursor.getInt(cursor
							.getColumnIndex("soundid"));
					svo.Dateiname = cursor.getString(cursor
							.getColumnIndex("filename"));
					svo.isFavorite = cursor.getInt(cursor
							.getColumnIndex("isfavorite"));
					svo.downloaded = cursor.getInt(cursor
							.getColumnIndex("downloaded"));
					svo.Anzeigename = cursor.getString(cursor
							.getColumnIndex("Anzeigename"));
					svo.Eventbased = cursor.getString(cursor
							.getColumnIndex("Eventbased"));
					svo.Eventstartdate = cursor.getString(cursor
							.getColumnIndex("Eventstartdate"));
					svo.Eventenddate = cursor.getString(cursor
							.getColumnIndex("Eventenddate"));
					svo.soundtype = cursor.getString(cursor
							.getColumnIndex("soundtype"));
					svo.color = color;
					favoriteSoundsList.add(svo);
				}
			}
			cursorCount = cursor.getCount();
			cursor.close();
			fillSoundsOnUI();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return cursorCount;
	}

	void fillSoundsOnUI() {
		int counter = 0;
		favoriteSoundsLinearLayout.removeAllViews();
		LinearLayout vert_soundsLayout = new LinearLayout(getActivity());

		vert_soundsLayout.setOrientation(LinearLayout.VERTICAL);
		Display display = getActivity().getWindowManager().getDefaultDisplay();
		int width = display.getWidth(); // deprecated
		int height = display.getHeight(); // deprecated

		vert_soundsLayout.setLayoutParams(new LinearLayout.LayoutParams(
				(width * 40) / 100, height));

		for (int count = 0; count < favoriteSoundsList.size(); count++) {
			final SowndsVO svo = favoriteSoundsList.get(count);

			// sounds button
			final Button soundsBtn = new Button(getActivity());
			RelativeLayout.LayoutParams mainsoundLayoutParam = new RelativeLayout.LayoutParams(
					RelativeLayout.LayoutParams.MATCH_PARENT, height / 4);
			mainsoundLayoutParam.setMargins(2, 2, 2, 2);

			// favorite image
			final Button favoriteImage = new Button(getActivity());
			favoriteImage.setAlpha(0.7f);
			favoriteImage.setBackgroundResource(R.drawable.star);
			favoriteImage.setGravity(Gravity.CENTER_VERTICAL);
			RelativeLayout.LayoutParams favoriteImageparams = new LayoutParams(
					50, 50);
			favoriteImageparams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
			favoriteImageparams.setMargins(5, ((height / 4) / 2) - 25, 0, 0);
			favoriteImage.setLayoutParams(favoriteImageparams); // causes layout

			// sound layout
			final RelativeLayout soundsBtnLayout = new RelativeLayout(
					getActivity());

			soundsBtnLayout.setLayoutParams(mainsoundLayoutParam);
			soundsBtnLayout.setPadding(5, 5, 5, 5);
			soundsBtn.setLayoutParams(new RelativeLayout.LayoutParams(
					RelativeLayout.LayoutParams.MATCH_PARENT,
					RelativeLayout.LayoutParams.MATCH_PARENT));
			soundsBtn.setGravity(Gravity.CENTER);
			soundsBtn.setBackgroundColor(svo.color);

			soundsBtn.setTextColor(Color.WHITE);
			soundsBtn.setText(svo.Anzeigename);
			soundsBtn.setId(count);
			final int var = count;

			soundsBtn.setOnLongClickListener(new OnLongClickListener() {
				@Override
				public boolean onLongClick(View v) {
					// TODO Auto-generated method stub
					SowndsVO oldSowndsVO = null;
					boolean sameSounds = false;
					if (Constants.isPlaying) {
						oldSowndsVO = favoriteSoundsList.get(oldButton.getId());
						animation.animateReverseFlip(oldButton,
								favoriteSoundsList.get(oldButton.getId()));
						animation.stopSound(svo, soundsBtn, favoriteImage);
						if (oldSowndsVO != null) {
							if (oldSowndsVO.Dateiname.equals(svo.Dateiname)) {
								sameSounds = true;
							}
						}
					}
					Constants.isFromFavorite = true;
					oldButton = new Button(getActivity());
					oldButton = soundsBtn;
					animation.longPressedAnimation(soundsBtn, svo,
							favoriteImage, soundsBtnLayout);

					return true;
				}
			});

			soundsBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					SowndsVO oldSowndsVO = null;
					boolean sameSounds = false;
					if (Constants.isPlaying) {
						oldSowndsVO = favoriteSoundsList.get(oldButton.getId());
						animation.animateReverseFlip(oldButton,
								favoriteSoundsList.get(oldButton.getId()));
						animation.stopSound(svo, soundsBtn, favoriteImage);
						if (oldSowndsVO != null) {
							if (oldSowndsVO.Dateiname.equals(svo.Dateiname)) {
								sameSounds = true;
								oldButton = new Button(getActivity());
							}
						}
					}

					if (sameSounds == false) {
						oldButton = new Button(getActivity());
						oldButton = soundsBtn;
						oldLayout = new RelativeLayout(getActivity());
						oldLayout = soundsBtnLayout;

						Constants.isPlaying = true;
						animation.animateFlip(oldButton,
								favoriteSoundsList.get(var));
						animation.playSound(oldButton,
								favoriteSoundsList.get(var), favoriteImage);

					}

				}
			});
			counter++;

			if (svo.isFavorite == 0)
				favoriteImage.setVisibility(View.INVISIBLE);
			else
				favoriteImage.setVisibility(View.VISIBLE);

			soundsBtnLayout.addView(soundsBtn);
			soundsBtn.setAlpha(1.0f);
			soundsBtnLayout.addView(favoriteImage);
			vert_soundsLayout.addView(soundsBtnLayout);
			if (count == favoriteSoundsList.size() - 1 && counter != 4) {
				counter = 0;
				vert_soundsLayout.setId(100 + count);
				favoriteSoundsLinearLayout.addView(vert_soundsLayout);
			} else if (counter == 4) {
				counter = 0;
				vert_soundsLayout.setId(100 + count);
				favoriteSoundsLinearLayout.addView(vert_soundsLayout);
				vert_soundsLayout = new LinearLayout(getActivity());
				vert_soundsLayout.setOrientation(LinearLayout.VERTICAL);
				vert_soundsLayout
						.setLayoutParams(new LinearLayout.LayoutParams(
								(width * 40) / 100, height));
			}
		}
	}

}
