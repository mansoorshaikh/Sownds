package com.mobiwebcode.Sownds;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Environment;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

import com.mobiwebcode.Sownds.VO.SowndsVO;

public class Animation {
	SowndsVO currentSowndsVO = null;
	MediaPlayer mediaPlayer = null;
	String STORAGE_PATH = "/Sownds/";
	Thread worker = null, joiner = null;
	static Activity mContext = null;
	ProgressBar progressBar = null;
	DBHelper dbHelper = null;
	ShareUtility shareUtility = null;
	public static Animation animation = null;
	int soundcount = -1;
	boolean interruptedAllDownload = false;

	public Animation(Activity context) {
		// TODO Auto-generated constructor stub
		mediaPlayer = new MediaPlayer();
		mContext = context;
		Display display = mContext.getWindowManager().getDefaultDisplay();
		int width = display.getWidth(); // deprecated
		int height = display.getHeight(); // deprecated
		progressBar = new ProgressBar(mContext, null,
				android.R.attr.progressBarStyleSmall);
		RelativeLayout.LayoutParams favoriteImageparams = new LayoutParams(50,
				50);
		favoriteImageparams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
		favoriteImageparams.setMargins(5, ((height / 4) / 2) - 25, 0, 0);
		progressBar.setLayoutParams(favoriteImageparams);

		dbHelper = new DBHelper(mContext);
		shareUtility = new ShareUtility(context);
	}

	public static Animation newInstance(Activity context) {
		if (animation == null) {
			animation = new Animation(context);
		} else {
			mContext = context;
		}
		return animation;
	}

	void animateFlip(final Button btn, final SowndsVO svo) {
		final ObjectAnimator invisToVis = ObjectAnimator.ofFloat(btn,
				"rotationY", -90f, 0f);
		final Interpolator decelerator = new DecelerateInterpolator();
		invisToVis.setDuration(500);
		invisToVis.setInterpolator(decelerator);

		invisToVis.addListener(new AnimatorListenerAdapter() {
			@Override
			public void onAnimationEnd(Animator anim) {

			}
		});
		invisToVis.start();
	}

	void animateReverseFlip(final Button btn, final SowndsVO svo) {
		final ObjectAnimator invisToVis = ObjectAnimator.ofFloat(btn,
				"rotationY", 90f, 0f);
		final Interpolator decelerator = new DecelerateInterpolator();
		invisToVis.setDuration(500);
		invisToVis.setInterpolator(decelerator);
		btn.setBackgroundColor(svo.color);
		btn.setText(svo.Anzeigename);
		invisToVis.addListener(new AnimatorListenerAdapter() {
			@Override
			public void onAnimationEnd(Animator anim) {

			}
		});
		invisToVis.start();
	}

	public static Bitmap scaleDown(Bitmap realImage, float maxImageSize,
			boolean filter, int color) {
		float ratio = Math.min((float) maxImageSize / realImage.getWidth(),
				(float) maxImageSize / realImage.getHeight());
		int width = Math.round((float) ratio * realImage.getWidth());
		int height = Math.round((float) ratio * realImage.getHeight());

		Bitmap myBitmap = Bitmap.createScaledBitmap(realImage, width, height,
				filter);
		int[] allpixels = new int[myBitmap.getHeight() * myBitmap.getWidth()];

		myBitmap.getPixels(allpixels, 0, myBitmap.getWidth(), 0, 0,
				myBitmap.getWidth(), myBitmap.getHeight());

		for (int i = 0; i < myBitmap.getHeight() * myBitmap.getWidth(); i++) {
			if (allpixels[i] == Color.TRANSPARENT)
				allpixels[i] = color;
			else
				System.out.println("outside white");
		}

		myBitmap.setPixels(allpixels, 0, myBitmap.getWidth(), 0, 0,
				myBitmap.getWidth(), myBitmap.getHeight());

		return myBitmap;
	}

	void playSound(final Button btn, final SowndsVO svo,
			final Button favoriteImage) {
		try {
			btn.setBackgroundResource(svo.resourceImageColor);
			btn.setText("");
			favoriteImage.setVisibility(Button.INVISIBLE);
			mediaPlayer.reset();
			String filePath = Environment.getExternalStorageDirectory()
					+ "/Sownds/" + svo.Dateiname;
			if (svo.soundtype.equals("mainsound")) {
				filePath = filePath.replace(" ", "%20");
				filePath = filePath + ".mp3";
			}
			new File(filePath).exists();
			mediaPlayer.setDataSource(filePath);
			mediaPlayer.prepare();
			mediaPlayer.start();
			mediaPlayer.setOnCompletionListener(new OnCompletionListener() {
				@Override
				public void onCompletion(MediaPlayer mp) {
					// TODO Auto-generated method stub
					animateReverseFlip(btn, svo);
					if (svo.isFavorite == 1)
						favoriteImage.setVisibility(Button.VISIBLE);
					Constants.isPlaying = false;
				}
			});
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	void stopSound(final SowndsVO svo, final Button soundBtn,
			final Button favoriteImage) {
		mediaPlayer.reset();

		if (favoriteImage != null) {
			if (svo.isFavorite == 1)
				favoriteImage.setVisibility(Button.VISIBLE);
		}
		Constants.isPlaying = false;
	}

	void displayLongPressOptionsDialogue(final Button btn, final SowndsVO svo,
			final Button favBtn) {
		String favoriteItem = "";
		if (svo.isFavorite == 0) {

			favoriteItem = mContext.getResources().getString(
					R.string.add_to_favorites);
		} else {
			favoriteItem = mContext.getResources().getString(
					R.string.remove_from_favorites);
		}
		String[] MenuItems;
		MenuItems = new String[4];
		if (svo.soundtype.equals("recordedsound")) {
			MenuItems = new String[5];
			MenuItems[4] = mContext.getResources().getString(
					R.string.delete_recorded_sound);
		} else {

		}
		MenuItems[0] = favoriteItem;
		MenuItems[1] = mContext.getResources().getString(
				R.string.share_using_other_apps);
		MenuItems[2] = mContext.getResources().getString(
				R.string.set_as_ringtone);
		MenuItems[3] = mContext.getResources().getString(
				R.string.report_problem);

		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				mContext);
		// set title
		alertDialogBuilder.setTitle(svo.Anzeigename);
		alertDialogBuilder
				.setCancelable(true)
				.setSingleChoiceItems(MenuItems, 0,
						new DialogInterface.OnClickListener() {

							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								// TODO Auto-generated method stub
								if (which == 0) {
									if (svo.isFavorite == 0) {
										dbHelper.addToFavorite(svo);
										favBtn.setVisibility(View.VISIBLE);
										svo.isFavorite = 1;
									} else if (svo.isFavorite == 1) {
										dbHelper.removeFromFavorites(svo);
										favBtn.setVisibility(View.INVISIBLE);
										svo.isFavorite = 0;
									}
									FavoriteSounds.newInstance("")
											.readSoundsDB();
									if (Constants.isFromFavorite == true) {
										MainSounds.newInstance("")
												.readSoundsDB();
										YourSounds.newInstance("")
												.readSoundsDB();
									}
								} else if (which == 1) {
									shareUtility.shareSoundOnSocialMedia(svo,
											mContext);
								} else if (which == 2) {
									shareUtility.setSoundAsRingtone(svo,
											mContext);
								} else if (which == 3) {
									shareUtility.reportSound(svo, mContext);
								} else if (which == 4) {
									dbHelper.deleteSound(svo);
								}
								Constants.isFromFavorite = false;
								dialog.cancel();
							}
						})
				.setPositiveButton(
						mContext.getResources().getString(R.string.cancel),
						new DialogInterface.OnClickListener() {
							@SuppressLint("NewApi")
							public void onClick(DialogInterface dialog1, int id) {
								dialog1.cancel();
							}
						});

		// create alert dialog
		final AlertDialog alertDialog = alertDialogBuilder.create();
		// show it
		alertDialog.show();

	}

	void longPressedAnimation(final Button btn, final SowndsVO svo,
			final Button favBtn, final RelativeLayout layout) {
		android.view.animation.Animation animZoomIn = AnimationUtils
				.loadAnimation(mContext, R.anim.zoomin);
		btn.startAnimation(animZoomIn);
		final android.view.animation.Animation animZoomOut = AnimationUtils
				.loadAnimation(mContext, R.anim.zoomout);
		animZoomOut.setAnimationListener(new AnimationListener() {

			@Override
			public void onAnimationEnd(
					android.view.animation.Animation animation) {
				// TODO Auto-generated method stub
				String filePath = Environment.getExternalStorageDirectory()
						+ STORAGE_PATH + svo.Dateiname;
				if (svo.soundtype.equals("mainsound")) {
					filePath = filePath.replace(" ", "%20");
					filePath = filePath + ".mp3";
				}
				File fcreate = new File(filePath);
				if (fcreate.exists())
					displayLongPressOptionsDialogue(btn, svo, favBtn);
				else if (svo.soundtype.equals("mainsound"))
					downloadSound(svo, layout, btn, favBtn);
			}

			@Override
			public void onAnimationRepeat(
					android.view.animation.Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationStart(
					android.view.animation.Animation animation) {
				// TODO Auto-generated method stub

			}
		});

		animZoomIn.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationEnd(
					android.view.animation.Animation animation) {
				// TODO Auto-generated method stub
				btn.startAnimation(animZoomOut);
			}

			@Override
			public void onAnimationRepeat(
					android.view.animation.Animation animation) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onAnimationStart(
					android.view.animation.Animation animation) {
				// TODO Auto-generated method stub

			}
		});

	}

	int checkSoundExists(SowndsVO svo) {
		File file = new File(Environment.getExternalStorageDirectory(),
				STORAGE_PATH + svo.Dateiname.replace(" ", "%20") + ".mp3");
		if (file.exists()) {
			return 0;
		}
		return 1;
	}

	void downloadSound(final SowndsVO svo, final RelativeLayout layout,
			final Button btn, final Button favButton) {
		worker = new Thread(new Runnable() {
			public void run() {/* work thread stuff here */
				try {
					mContext.runOnUiThread(new Runnable() {
						@Override
						public void run() {
							// Your code to run in GUI thread here
							layout.addView(progressBar);
						}// public void run() {
					});

					URL url = new URL("http://deineeigeneapp.de"
							+ "/SowndsSounds/"
							+ svo.Dateiname.replace(" ", "%20"));
					URLConnection conn = url.openConnection();
					int contentLength = conn.getContentLength();

					DataInputStream stream = new DataInputStream(
							url.openStream());

					byte[] buffer = new byte[contentLength];
					stream.readFully(buffer);
					stream.close();
					File folder = new File(
							Environment.getExternalStorageDirectory()
									+ "/Sownds/");
					if (!folder.exists()) {
						folder.mkdir();
					}
					File fcreate = new File(
							Environment.getExternalStorageDirectory()
									+ STORAGE_PATH
									+ svo.Dateiname.replace(" ", "%20")
									+ ".mp3");
					if (!fcreate.exists()) {
						fcreate.createNewFile();
					}
					DataOutputStream fos = new DataOutputStream(
							new FileOutputStream(fcreate));
					fos.write(buffer);
					fos.flush();
					fos.close();

				} catch (Exception ioe) {
					ioe.printStackTrace();
				}
			}
		});
		worker.start();
		// observer thread for notifications
		joiner = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					worker.join();
				} catch (Exception e) {
					// TODO: handle exception
				} finally {
					mContext.runOnUiThread(new Runnable() {
						@Override
						public void run() {
							// Your code to run in GUI thread here
							File fcreate = new File(Environment
									.getExternalStorageDirectory()
									+ STORAGE_PATH
									+ svo.Dateiname.replace(" ", "%20")
									+ ".mp3");
							if (fcreate.exists()) {
								// Your code to run in GUI thread here
								btn.setAlpha(1.0f);
								dbHelper.updateDownloadStatus(svo);
								svo.downloaded = 1;
								Constants.isDownloading = false;
								Constants.isPlaying = true;
								layout.removeView(progressBar);
								animateFlip(btn, svo);
								playSound(btn, svo, favButton);
							}
						}// public void run() {
					});

				}
			}
		});
		joiner.start();
	}

	void stopDownload(RelativeLayout layout) {
		try {
			worker.interrupt();
			joiner.interrupt();
			worker = null;
			joiner = null;
			Constants.isDownloading = false;
			ViewGroup viewParent = (ViewGroup) progressBar.getParent();
			if (viewParent != null)
				viewParent.removeView(progressBar);
		} catch (Exception e) {
			// TODO: handle exception
		} finally {

		}
	}

	void stopDownloadAllSounds() {
		try {
			interruptedAllDownload = true;
			if (!worker.isInterrupted() && !joiner.isInterrupted()) {
				worker.interrupt();
				joiner.interrupt();
				worker = null;
				joiner = null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		} finally {

		}
	}

	void downloadAllSounds(final ArrayList<SowndsVO> soundsList,
			final TextView textview) {
		if (worker != null && joiner != null) {
			worker.interrupt();
			joiner.interrupt();
			worker = null;
			joiner = null;
		}
		if (interruptedAllDownload == false) {
			if (soundcount != soundsList.size() - 1) {//
				currentSowndsVO = soundsList.get(++soundcount);
				downloadAllThread(soundsList, textview);
			} else {
				mContext.runOnUiThread(new Runnable() {
					@Override
					public void run() {
						// Your code to run in GUI thread here
						textview.setText("All sounds Downloaded successfully");
					}// public void run() {
				});
			}

		}
	}

	void downloadAllThread(final ArrayList<SowndsVO> soundsList,
			final TextView textview) {
		worker = new Thread(new Runnable() {
			public void run() {/* work thread stuff here */
				try {
					final SowndsVO svo = currentSowndsVO;

					File folder = new File(
							Environment.getExternalStorageDirectory()
									+ "/Sownds/");
					if (!folder.exists()) {
						folder.mkdir();
					}
					File fcreate = new File(
							Environment.getExternalStorageDirectory()
									+ STORAGE_PATH
									+ svo.Dateiname.replace(" ", "%20")
									+ ".mp3");
					if (!fcreate.exists()) {
						URL url = new URL("http://deineeigeneapp.de"
								+ "/SowndsSounds/"
								+ svo.Dateiname.replace(" ", "%20"));
						URLConnection conn = url.openConnection();
						int contentLength = conn.getContentLength();

						DataInputStream stream = new DataInputStream(
								url.openStream());

						byte[] buffer = new byte[contentLength];
						stream.readFully(buffer);
						stream.close();
						fcreate.createNewFile();
						mContext.runOnUiThread(new Runnable() {
							@Override
							public void run() {
								// Your code to run in GUI thread here
								textview.setText("Downloading Sound "
										+ svo.soundid + " Sound Name "
										+ svo.Anzeigename
										+ " of total sounds 364");
							}// public void run() {
						});
						DataOutputStream fos = new DataOutputStream(
								new FileOutputStream(fcreate));
						fos.write(buffer);
						fos.flush();
						fos.close();
					} else {
						mContext.runOnUiThread(new Runnable() {
							@Override
							public void run() {
								// Your code to run in GUI thread here
								textview.setText("Downloading Sound "
										+ svo.soundid + " Sound Name "
										+ svo.Anzeigename
										+ " of total sounds 364 Already exists");
							}// public void run() {
						});
					}
				} catch (Exception ioe) {
					ioe.printStackTrace();
				}
			}
		});
		worker.start();
		// observer thread for notifications
		joiner = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					worker.join();
				} catch (Exception e) {
					// TODO: handle exception

				} finally {
					currentSowndsVO.downloaded = 1;
					dbHelper.updateDownloadStatus(currentSowndsVO);
					currentSowndsVO.downloaded = 1;
					downloadAllSounds(soundsList, textview);
				}
			}

		});
		joiner.start();
	}

}
