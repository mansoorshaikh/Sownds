package com.mobiwebcode.Sownds;

interface NavigateViewInterface {
	void navigate();
}
